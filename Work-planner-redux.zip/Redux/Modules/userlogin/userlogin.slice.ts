"use client";
import { createSlice } from "@reduxjs/toolkit";

import { IReduxUserLogin } from "./userlogin";

const reducerName = "userLogin";

type AddUserDetailsAction = {
  type: string;
  payload: IReduxUserLogin.UserDetails;
};

export const initialState: IReduxUserLogin.IInitialLoginState = {
  userDetails: {
    id: "",
    scope: "",
    access_token: "",
    token_type: "",
  },
};

export const userLoginSlice = createSlice({
  name: reducerName,
  initialState,
  reducers: {
    adduserDetails: (
      state: IReduxUserLogin.IInitialLoginState,
      action: AddUserDetailsAction
    ) => {
      state.userDetails = action.payload;
    },
    // {"userLogin":"{\"userDetails\":{\"id\":\"U027V535PQV\",\"user_name\":\"Pavani\",\"profile_pic\":\"https://avatars.slack-edge.com/2021-07-19/2289341431186_1fd2a6bd35d83caf59f3_512.jpg\",\"profile_pic_72\":\"https://avatars.slack-edge.com/2021-07-19/2289341431186_1fd2a6bd35d83caf59f3_72.jpg\",\"access_token\":\"xoxp-120000646596-2267173193845-6489960244099-8f8ec6d2a35efc369223d8d9e6633c16\",\"user_type\":\"QA_ENGINEER\"}}","_persist":"{\"version\":1,\"rehydrated\":true}"}
    deleteUserDetails: (state: IReduxUserLogin.IInitialLoginState) => {
      state = {
        userDetails: {
          id: "",
          scope: "",
          access_token: "",
          token_type: "",
        },
      };
    },
  },
});

export const { adduserDetails, deleteUserDetails } = userLoginSlice.actions;
export const userLoginSliceReducer = { [reducerName]: userLoginSlice.reducer };
